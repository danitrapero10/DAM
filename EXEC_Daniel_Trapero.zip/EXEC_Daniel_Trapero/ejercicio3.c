#include <stdio.h>
#include <stdlib.h>

int  main(){
	int n=0;
	int npositivo = 0;
	int nnegativo = 0;


return 0;
}


