#include <stdio.h>
#include <stdlib.h>

int  main(){
	int n=0;
	int npositivo >= 0;
	int resultado_suma;
	printf("%d");
	while (n=0, npositivo>=0, npositivo++){
		resultado_suma = npositivo + n;
		printf("%d\n", resultado_suma);
	}
	

return 0;
}


