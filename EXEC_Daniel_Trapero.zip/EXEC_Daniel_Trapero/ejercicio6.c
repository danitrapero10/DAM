#include <stdio.h>
#include <stdlib.h>

int  main(){
	int n=0;
	int num_valido = 7;
	int no_valido;
        do (n=0, n!=7){
		printf("Número no válido", &no_valido)
        } while (n=7){
		printf("Has ingresado el número válido %d\n", &num_valido)
	}
return 0;
}


