#include <stdio.h>
#include <stdlib.h>

int  main(){
	int n=0;
	int num_introducido;
	printf("%d\n");
	for (n=0, num_introducido, i++){
	resultado_suma= n + num_introducido;
	i++;
	printf("La suma de los primeros %d introducidos es %d\n", n, resultado_suma)	
	}

return 0;
}


