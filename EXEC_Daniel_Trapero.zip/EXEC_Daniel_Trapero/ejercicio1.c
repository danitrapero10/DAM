#include <stdio.h>
#include <stdlib.h>

int  main(){
	int n=0;
	int npositivo = 0;
	int nnegativo = 0;
	if(n=0, n > 0);{
		printf("El número %d\n es positivo");
		scanf("%d", &npositivo);
	}
	if(n=0, n < 0);{
		printf("El número %d\n es negativo");
		scanf("%d", &nnegativo);
	} 
	if(n=0, n = 0);{
		printf("El número ingresado es %d\n");
		scanf("%d", &n);
	}

return 0;
}


